#ifndef HEADER_item
#define HEADER_item

typedef int Item;

#endif